package az.nuansmebel.salyan;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.print.PrintManager;
import android.content.Context;
import android.webkit.JavascriptInterface;
import android.print.PrintManager;
import android.content.Context;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    WebView w = new WebView(this);
    w.setWebViewClient(new WebViewClient());
    w.addJavascriptInterface(new PrintBridge(this, w), "Android");
    w.addJavascriptInterface(new PrintBridge(this, w), "Android");
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    w.loadUrl("file:///android_asset/index.html");
    setContentView(w);
  }

  public static class PrintBridge {
    private final Activity activity; private final WebView webView;
    PrintBridge(Activity a, WebView w){activity=a;webView=w;}
    @JavascriptInterface public void printReceipt(){
      activity.runOnUiThread(() -> {
        PrintManager pm=(PrintManager)activity.getSystemService(Context.PRINT_SERVICE);
        if(pm!=null) pm.print("Nuans_Mebel_Sifaris_Qebzi", webView.createPrintDocumentAdapter("Nuans_Mebel_Sifaris_Qebzi"), null);
      });
    }
  }
}
