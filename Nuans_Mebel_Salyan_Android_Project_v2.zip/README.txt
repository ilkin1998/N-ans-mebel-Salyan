NÜANS MEBEL SALYAN — ANDROID LAYİHƏSİ

Bu layihə Android Studio ilə APK yaratmaq üçün hazırdır.

Android Studio: Open -> bu qovluğu seç -> Build -> Generate App Bundles or APKs -> Generate APKs.
APK adətən app/build/outputs/apk/debug/app-debug.apk ünvanında yaranır.
